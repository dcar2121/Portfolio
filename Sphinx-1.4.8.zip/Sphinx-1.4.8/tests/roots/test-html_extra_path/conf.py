# -*- coding: utf-8 -*-

master_doc = 'index'

html_extra_path = ['extra', 'subdir']
exclude_patterns = ['**/_build', '**/.htpasswd']
