============================
test-ext-inheritance_diagram
============================

.. inheritance-diagram:: test.Foo
