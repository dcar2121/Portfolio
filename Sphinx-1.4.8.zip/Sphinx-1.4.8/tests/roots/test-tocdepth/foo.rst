===
Foo
===

should be 1

Foo A
=====

should be 1.1

Foo A1
------

should be 1.1.1

Foo B
=====

should be 1.2

Foo B1
------

should be 1.2.1

