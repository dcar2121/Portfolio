# -*- coding: utf-8 -*-

master_doc = 'markup'
source_suffix = '.txt'
