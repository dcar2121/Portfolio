Baz A
-----

should be 2.1.1

