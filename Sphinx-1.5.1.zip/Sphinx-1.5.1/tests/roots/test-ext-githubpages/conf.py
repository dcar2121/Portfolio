# -*- coding: utf-8 -*-

extensions = ['sphinx.ext.githubpages']
master_doc = 'index'
