Test Math
=========

.. math:: a^2+b^2=c^2

Inline :math:`E=mc^2`

Second math

.. math:: e^{i\pi}+1=0

Multi math equations

.. math::

   S &= \pi r^2

   V &= \frac{4}{3} \pi r^3
