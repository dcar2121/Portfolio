===
Bar
===

Bar A
=====

.. figure:: rimg.png

   should be Fig.2.1

.. csv-table:: should be Table 2.1
   :header-rows: 0

   hello,world

.. code-block:: python
   :caption: should be List 2.1

   print('hello world')

.. toctree::

   baz

.. figure:: rimg.png

   should be Fig.2.3

.. csv-table:: should be Table 2.3
   :header-rows: 0

   hello,world

.. code-block:: python
   :caption: should be List 2.3

   print('hello world')

Bar B
=====

Bar B1
------

.. figure:: rimg.png

   should be Fig.2.4

.. csv-table:: should be Table 2.4
   :header-rows: 0

   hello,world

.. code-block:: python
   :caption: should be List 2.4

   print('hello world')
